#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include "atv_3header.h"

// Lista 3 (Atividade Mercado - em TAD)
// 17/04/2023 (segunda-feira)
// Jansen Rodrigues de Avila (jansenavila.aluno@unipampa.edu.br)


void main (void) {

	int nProdutos, selector=0, nApresenta, balanco, tamanhoTotal=0, tamanhoReal, busc_setor, qtdVenda;
	product *mercado=NULL;
	char achaNome[20], produtoVenda[20];

	printf("Digite a quantidade de produtos que voce deseja cadastrar: ");
	scanf("%d", &nProdutos);
	tamanhoReal = nProdutos;

	mercado = (product*) malloc (sizeof(product)*nProdutos);

	printf("\nLISTA DE SETORES\n1) Limpeza\n2) Higiene\n3) Hortifruti\n4) Padaria\n5) Bazar\n6) Bebidas\n-------------------------------------------------------------\n");
	printf("\nOPCOES\n1) Inserir Produtos\n2) Apresentar Produto\n3) Todos Produtos\n4) Balanco\n5) Busca por Nome\n6) Busca por Setor\n7) Venda\n8) Sair\n");

	do {
		printf("Selecione: ");
		scanf("%d", &selector);

		switch(selector){
			case 1:

			if(tamanhoTotal < tamanhoReal){
			
				mercado[tamanhoTotal] = insereProdutos();
				printf("Produto Adicionado, voce ainda possui %d produtos restantes\n", tamanhoReal-(tamanhoTotal+1));
				tamanhoTotal++;

				}
			else {
				printf("Nao ha possibilidade de adicionar mais produtos\n\n");
				} 
			break;

			case 2:
			printf("Qual produto voce deseja ver: ");
			scanf("%d", &nApresenta);
			apresentaProduto(mercado,nApresenta-1);
			break;

			case 3: 
				for(int i=0; i<tamanhoTotal; ++i) {
				apresentaProduto(mercado,i);
				}
			break;

			case 4:
			balanco = calculaBalanco(mercado, nProdutos-1); // para não começar em lixo de memória.
			printf("Balanco: %d ao total\n\n", balanco);
			break;

			case 5:
			printf("Digite o nome que deseja achar: ");
			scanf("%s", achaNome);
			buscaNome(mercado, achaNome, tamanhoTotal);
			break;

			case 6:
			printf("Digite o setor que voce deseja achar: ");
			scanf("%d", &busc_setor);
			buscaSetor(mercado, busc_setor, tamanhoTotal);
			break;

			case 7:
			printf("Produto: ");
			scanf("%s", produtoVenda);
			printf("Quantidade: ");
			scanf("%d", &qtdVenda);
			mercado = venda(mercado, produtoVenda, qtdVenda, tamanhoTotal);
			break; 

		}

	}while(selector!=8);

}
