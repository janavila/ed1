// Lista 3 (Atividade Mercado - em TAD)
// 17/04/2023 (segunda-feira)
// Jansen Rodrigues de Avila (jansenavila.aluno@unipampa.edu.br)

enum setores {limpeza=1,higiene=2,hortifruti=3, padaria=4, bazar=5, bebidas=6};

typedef struct produto {
	char nome[15];
	enum setores sector;
	int quantidade, preco;

}product;

product insereProdutos();
void apresentaProduto(product *aux,int produto);
int calculaBalanco(product *aux,int nProduto);
void buscaNome(product *aux, char *nome, int tamanhoReal);
void buscaSetor(product *aux, int set_aux, int tamanhoReal);
void printaSetor(product *aux, int n);
product *venda(product *aux, char *produto, int qtdVenda, int tamanhoReal);