// Lista 5 - Lista Duplamente Encadeada (LDE)
// 11/05/2023 - (Quinta-feira);
// Jansen Rodrigues de Avila (jansenavila.aluno@unipampa.edu.br)


struct musica {
	char titulo[256];
	char artista[256];
	char letra[256];
	int codigo;
	int execucoes;
};

typedef struct musica musics;

struct nodo {
	struct nodo *prox;
	musics *info;
	struct nodo *ant;
};

struct desc_LDE { // descritor que controla a lista.
	struct nodo *LDE; // aponta para o começo da lista, sempre (primeiro)
	int tamanho; // controla o tamanho da lista.
};

struct desc_LDE *criaLista(void);
void *insereNodo(struct desc_LDE *descritor, int posicao);
struct nodo *criaNodo(void);
musics *criaMusica(void);
void *imprimeNodo(struct desc_LDE *descritor);
void *consultaNodo(struct desc_LDE *descritor, int consultor);
void *removeNodo(struct desc_LDE *descritor, int removedor);