#include <stdio.h>
#include <stdlib.h>
#include "reader.h"

// Lista 5 - Lista Duplamente Encadeada (LDE)
// 11/05/2023 - (Quinta-feira);
// Jansen Rodrigues de Avila (jansenavila.aluno@unipampa.edu.br)

void main (void) {

	struct desc_LDE *descritor=NULL;
	int seletor=0, posicao, consultor, removedor;

	do {
		printf("-----MENU-----\n1) Criar Lista\n2) Inserir\n3) Remover\n4) Consulta\n5) Imprime\n6) Sair\n--------------------------\n");
		scanf("%d", &seletor);

		switch (seletor) {

		case 1: if(descritor != NULL) printf("Sua lista já foi criada\n\n");
			else {
				descritor = criaLista();
				printf("Lista criada com sucesso\n\n");
			}
			break;
		case 2:
				if(descritor == NULL) printf("Você ainda não criou a sua lista\n\n");
				else {

				if (descritor->tamanho == 0) insereNodo(descritor,0);
				else {
					printf("Diga a posição que você deseja inserir: ");
					scanf("%d", &posicao);
					insereNodo(descritor, posicao);
					printf("Inserção realizada com sucesso, tamanho da lista %d\n", descritor->tamanho);
					}
				}
			break;
		case 3:
				if(descritor == NULL) printf("Você ainda não criou a sua lista\n\n");
				else {
				printf("Diga a posição que você deseja remover: ");
				scanf("%d", &removedor);
					if(removedor > descritor->tamanho || removedor <= 0) printf("Posição inválida\n");
					else removeNodo(descritor,removedor);
				}
			break;
		case 4:
				if(descritor == NULL) printf("Lista ainda não foi criada\n\n");
				else {
				printf("Diga a posição que você deseja consultar: ");
				scanf("%d", &consultor);
				if(consultor > descritor->tamanho) printf("Posição inválida\n");
				else consultaNodo(descritor,consultor);
				}
			break;
		case 5: if(descritor != NULL && descritor->tamanho > 0) imprimeNodo(descritor);
				else printf("Você não possui elementos\n\n");
			break;
		case 6: printf("Obrigado por utilizar \n");
			break;
		default: 
			break;
		}

	} while (seletor != 6);



}