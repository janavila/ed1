#include <stdio.h>
#include <stdlib.h>
#include "reader.h"

// Lista 5 - Lista Duplamente Encadeada (LDE)
// 11/05/2023 - (Quinta-feira);
// Jansen Rodrigues de Avila (jansenavila.aluno@unipampa.edu.br)

struct desc_LDE *criaLista() {

	struct desc_LDE *auxiliar=NULL;

	auxiliar = (struct desc_LDE*) malloc (sizeof(struct desc_LDE));
	auxiliar->LDE=NULL;
	auxiliar->tamanho=0;

	return auxiliar;

}

musics *criaMusica() {

	musics *auxiliar;

	auxiliar = (musics*) malloc (sizeof(musics));

		printf("Título: ");
		setbuf(stdin,NULL);
		scanf("%[^\n]s", auxiliar->titulo);
		setbuf(stdin,NULL);
		printf("Artista: ");
		setbuf(stdin,NULL);
		scanf("%[^\n]s", auxiliar->artista);
		setbuf(stdin,NULL);
		printf("Letra: ");
		scanf("%[^\n]s", auxiliar->letra);
		printf("Codigo: ");
		scanf("%d", &(auxiliar->codigo));
		printf("Execuções: ");
		scanf("%d", &(auxiliar->execucoes));

	return auxiliar;
}

struct nodo *criaNodo(void) {

	struct nodo *auxiliar=NULL;

	auxiliar = (struct nodo*) malloc (sizeof(struct nodo));

	auxiliar->info = criaMusica();
	auxiliar->ant = NULL;
	auxiliar->prox = NULL;

	return auxiliar;

}

void *insereNodo(struct desc_LDE *descritor, int posicao) {

	struct nodo *auxNodo=NULL, *auxLista=NULL, *anterior;
	int i=1;


	if (descritor->LDE == NULL) { // inserção do primeiro elemento.

		auxNodo = criaNodo();
		descritor->LDE = auxNodo;
		descritor->tamanho++;

	}

	else { // inserção no meio e no fim.

		auxLista = descritor->LDE;
		auxNodo = criaNodo();

		if(posicao >= descritor->tamanho) { // insere na última posição válida.
		
		while(auxLista->prox != NULL) { // sai da condição com auxLista->prox == NULL
			auxLista = auxLista->prox;
			}

			auxNodo->ant = auxLista;
			auxLista->prox = auxNodo;
			descritor->tamanho++;
		}

		else { // inserção na posição desejada.

		while(auxLista->prox != NULL) {
			anterior = auxLista;
			auxLista = auxLista->prox;
			i++;

			if(i == posicao) {
				auxNodo->prox = auxLista;
				auxLista->ant = auxNodo;
				anterior->prox = auxNodo;
				descritor->tamanho++;
			}

		}


		}
	}

	}

void *removeNodo(struct desc_LDE *descritor, int removedor) { // pensar se tiver apenas um elemento.

	struct nodo *auxLista, *anterior, *auxRemove;
	int i=1;

	auxLista = descritor->LDE;

	if(removedor == 1 && auxLista->prox != NULL) { // remove o primeiro
		anterior = auxLista->prox;
		anterior->ant = NULL;
		descritor->LDE = anterior;
		descritor->tamanho--;
		free(auxLista);
	}

	else if(removedor == descritor->tamanho) { // caso só tenha 1 elemento
		descritor->LDE = NULL;
		descritor->tamanho--;
		} 


	else {
		while(auxLista != NULL) {
			anterior = auxLista;
			auxLista = auxLista->prox;
			i++;
			if(i == removedor) {

				if(auxLista->prox == NULL) { // remove o último
					anterior->prox = NULL;
					free(auxLista);
					descritor->tamanho--;
				}
				else { // remove do meio.
				auxLista->prox->ant = anterior;
				anterior->prox = auxLista->prox;
				descritor->tamanho--;
		//		free(auxLista);
			}

		}
	}

}


}


void *consultaNodo(struct desc_LDE *descritor, int consultor) {

	struct nodo *aux=descritor->LDE;
	int i=1;

	for(aux; aux!= NULL; aux=aux->prox, i++) {

		if(consultor == i) {
		printf("Titulo: %s\n", aux->info->titulo);
		printf("Artista: %s\n", aux->info->artista);
		printf("Letra: %s\n", aux->info->letra);
		printf("Código: %d\n", aux->info->codigo);
		printf("Execucoes: %d\n\n", aux->info->execucoes);
		}
	}

}


void *imprimeNodo(struct desc_LDE *descritor) {

	struct nodo *aux=NULL;

	aux = descritor->LDE;

	while(aux != NULL) {

		printf("Titulo: %s\n", aux->info->titulo);
		printf("Artista: %s\n", aux->info->artista);
		printf("Letra: %s\n", aux->info->letra);
		printf("Código: %d\n", aux->info->codigo);
		printf("Execucoes: %d\n\n", aux->info->execucoes);

		aux = aux->prox;
	}

}













